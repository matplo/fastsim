bool isXHadron(int id);
bool isBHadron(int id);
bool isDHadron(int id);
int run(unsigned int nevents = 1000, double pThatmin = 10., int corb = 0, int qqbarflag = 0);
