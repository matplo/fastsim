void gener(int n, double pth, int q, int qqbarflag = 0)
{
  run(n, pth, q, qqbarflag);
}
