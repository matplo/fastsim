#ifdef __CINT__

#pragma link off all globals;
#pragma link off all classes;
#pragma link off all functions;

#pragma link C++ function isBHadron;
#pragma link C++ function isDHadron;
#pragma link C++ function run;

#pragma link C++ class PGun;
#pragma link C++ class HFGun;

#endif
