#!/bin/bash

#rm *.root
make clean
rm -rf CMakeCache.txt cmake_install.cmake *.dylib *.a *DICTS.* Makefile CMakeFiles
